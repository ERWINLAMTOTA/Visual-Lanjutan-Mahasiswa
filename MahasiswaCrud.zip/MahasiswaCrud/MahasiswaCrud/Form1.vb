﻿Public Class Form1
    Private Sub btnCreate_Click(sender As Object, e As EventArgs) Handles btnCreate.Click
        Try
            create("INSERT INTO mahasiswa (nim,nama,jurusan,year_join) VALUES ('" & nim.Text & "','" & nama.Text & "','" & jurusan.Text & "','" & year_join.Text & "')")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnReload_Click(sender As Object, e As EventArgs) Handles btnReload.Click
        Try
            reload("SELECT * FROM mahasiswa", DTGLIST)
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnUpdate_Click(sender As Object, e As EventArgs) Handles btnUpdate.Click
        Try
            updates("UPDATE mahasiswa SET nim='" & nim.Text & "', nama='" & nama.Text & "', jurusan='" & jurusan.Text & "', year_join='" & year_join.Text & "' WHERE mhsid='" & mhsid.Text & "'")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub DTGLIST_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DTGLIST.CellContentClick
        mhsid.Text = DTGLIST.CurrentRow.Cells(0).Value
        nim.Text = DTGLIST.CurrentRow.Cells(1).Value
        nama.Text = DTGLIST.CurrentRow.Cells(2).Value
        jurusan.Text = DTGLIST.CurrentRow.Cells(3).Value
        year_join.Text = DTGLIST.CurrentRow.Cells(4).Value
    End Sub

    Private Sub btnDelete_Click(sender As Object, e As EventArgs) Handles btnDelete.Click
        Try
            delete("DELETE FROM mahasiswa WHERE mhsid='" & mhsid.Text & "'")
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub btnNew_Click(sender As Object, e As EventArgs) Handles btnNew.Click
        mhsid.Text = ""
        nim.Clear()
        nama.Clear()
        jurusan.Clear()
        year_join.Clear()
    End Sub
End Class
