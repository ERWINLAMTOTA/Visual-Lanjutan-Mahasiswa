﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.mhsid = New System.Windows.Forms.TextBox()
        Me.nim = New System.Windows.Forms.TextBox()
        Me.nama = New System.Windows.Forms.TextBox()
        Me.jurusan = New System.Windows.Forms.TextBox()
        Me.year_join = New System.Windows.Forms.TextBox()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.btnNew = New System.Windows.Forms.Button()
        Me.btnUpdate = New System.Windows.Forms.Button()
        Me.btnDelete = New System.Windows.Forms.Button()
        Me.btnReload = New System.Windows.Forms.Button()
        Me.DTGLIST = New System.Windows.Forms.DataGridView()
        Me.Column1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Column5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.DTGLIST, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'mhsid
        '
        Me.mhsid.AccessibleName = "mhsid"
        Me.mhsid.Location = New System.Drawing.Point(22, 77)
        Me.mhsid.Name = "mhsid"
        Me.mhsid.PlaceholderText = "ID MAHASISWA"
        Me.mhsid.Size = New System.Drawing.Size(177, 23)
        Me.mhsid.TabIndex = 0
        Me.mhsid.Tag = "mhsid"
        '
        'nim
        '
        Me.nim.AccessibleName = "nim"
        Me.nim.Location = New System.Drawing.Point(22, 123)
        Me.nim.Name = "nim"
        Me.nim.PlaceholderText = "NIM"
        Me.nim.Size = New System.Drawing.Size(177, 23)
        Me.nim.TabIndex = 1
        Me.nim.Tag = "nim"
        '
        'nama
        '
        Me.nama.AccessibleName = "nama"
        Me.nama.Location = New System.Drawing.Point(22, 174)
        Me.nama.Name = "nama"
        Me.nama.PlaceholderText = "NAMA"
        Me.nama.Size = New System.Drawing.Size(177, 23)
        Me.nama.TabIndex = 2
        Me.nama.Tag = "nama"
        '
        'jurusan
        '
        Me.jurusan.AccessibleName = "jurusan"
        Me.jurusan.Location = New System.Drawing.Point(22, 227)
        Me.jurusan.Name = "jurusan"
        Me.jurusan.PlaceholderText = "JURUSAN"
        Me.jurusan.Size = New System.Drawing.Size(177, 23)
        Me.jurusan.TabIndex = 3
        Me.jurusan.Tag = "jurusan"
        '
        'year_join
        '
        Me.year_join.AccessibleName = "year_join"
        Me.year_join.Location = New System.Drawing.Point(22, 277)
        Me.year_join.Name = "year_join"
        Me.year_join.PlaceholderText = "TAHUN MASUK"
        Me.year_join.Size = New System.Drawing.Size(177, 23)
        Me.year_join.TabIndex = 4
        Me.year_join.Tag = "year_join"
        '
        'btnCreate
        '
        Me.btnCreate.AccessibleDescription = "btnCreate"
        Me.btnCreate.AccessibleName = "btnCreate"
        Me.btnCreate.Location = New System.Drawing.Point(22, 315)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(64, 23)
        Me.btnCreate.TabIndex = 5
        Me.btnCreate.Tag = "btnCreate"
        Me.btnCreate.Text = "CREATE"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'btnNew
        '
        Me.btnNew.AccessibleName = "btnNew"
        Me.btnNew.Location = New System.Drawing.Point(112, 315)
        Me.btnNew.Name = "btnNew"
        Me.btnNew.Size = New System.Drawing.Size(64, 23)
        Me.btnNew.TabIndex = 6
        Me.btnNew.Text = "RESET"
        Me.btnNew.UseVisualStyleBackColor = True
        '
        'btnUpdate
        '
        Me.btnUpdate.AccessibleName = "btnUpdate"
        Me.btnUpdate.Location = New System.Drawing.Point(22, 356)
        Me.btnUpdate.Name = "btnUpdate"
        Me.btnUpdate.Size = New System.Drawing.Size(64, 23)
        Me.btnUpdate.TabIndex = 7
        Me.btnUpdate.Text = "UPDATE"
        Me.btnUpdate.UseVisualStyleBackColor = True
        '
        'btnDelete
        '
        Me.btnDelete.AccessibleName = "btnDelete"
        Me.btnDelete.Location = New System.Drawing.Point(112, 356)
        Me.btnDelete.Name = "btnDelete"
        Me.btnDelete.Size = New System.Drawing.Size(64, 23)
        Me.btnDelete.TabIndex = 8
        Me.btnDelete.Text = "DELETE"
        Me.btnDelete.UseVisualStyleBackColor = True
        '
        'btnReload
        '
        Me.btnReload.AccessibleName = "btnReload"
        Me.btnReload.Location = New System.Drawing.Point(245, 315)
        Me.btnReload.Name = "btnReload"
        Me.btnReload.Size = New System.Drawing.Size(64, 23)
        Me.btnReload.TabIndex = 9
        Me.btnReload.Text = "RELOAD"
        Me.btnReload.UseVisualStyleBackColor = True
        '
        'DTGLIST
        '
        Me.DTGLIST.AccessibleName = "DTGLIST"
        Me.DTGLIST.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DTGLIST.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Column1, Me.Column2, Me.Column3, Me.Column4, Me.Column5})
        Me.DTGLIST.Location = New System.Drawing.Point(245, 77)
        Me.DTGLIST.Name = "DTGLIST"
        Me.DTGLIST.RowTemplate.Height = 25
        Me.DTGLIST.Size = New System.Drawing.Size(543, 230)
        Me.DTGLIST.TabIndex = 10
        '
        'Column1
        '
        Me.Column1.DataPropertyName = "mhsid"
        Me.Column1.HeaderText = "ID MAHASISWA"
        Me.Column1.Name = "Column1"
        '
        'Column2
        '
        Me.Column2.DataPropertyName = "nim"
        Me.Column2.HeaderText = "NIM"
        Me.Column2.Name = "Column2"
        '
        'Column3
        '
        Me.Column3.DataPropertyName = "nama"
        Me.Column3.HeaderText = "NAMA"
        Me.Column3.Name = "Column3"
        '
        'Column4
        '
        Me.Column4.DataPropertyName = "jurusan"
        Me.Column4.HeaderText = "JURUSAN"
        Me.Column4.Name = "Column4"
        '
        'Column5
        '
        Me.Column5.DataPropertyName = "year_join"
        Me.Column5.HeaderText = "TAHUN MASUK"
        Me.Column5.Name = "Column5"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Segoe UI", 15.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point)
        Me.Label2.Location = New System.Drawing.Point(22, 9)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(185, 28)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "TABEL MAHASISWA"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 418)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.DTGLIST)
        Me.Controls.Add(Me.btnReload)
        Me.Controls.Add(Me.btnDelete)
        Me.Controls.Add(Me.btnUpdate)
        Me.Controls.Add(Me.btnNew)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.year_join)
        Me.Controls.Add(Me.jurusan)
        Me.Controls.Add(Me.nama)
        Me.Controls.Add(Me.nim)
        Me.Controls.Add(Me.mhsid)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.DTGLIST, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents mhsid As TextBox
    Friend WithEvents nim As TextBox
    Friend WithEvents nama As TextBox
    Friend WithEvents jurusan As TextBox
    Friend WithEvents year_join As TextBox
    Friend WithEvents btnCreate As Button
    Friend WithEvents btnNew As Button
    Friend WithEvents btnUpdate As Button
    Friend WithEvents btnDelete As Button
    Friend WithEvents btnReload As Button
    Friend WithEvents DTGLIST As DataGridView
    Friend WithEvents Column1 As DataGridViewTextBoxColumn
    Friend WithEvents Column2 As DataGridViewTextBoxColumn
    Friend WithEvents Column3 As DataGridViewTextBoxColumn
    Friend WithEvents Column4 As DataGridViewTextBoxColumn
    Friend WithEvents Column5 As DataGridViewTextBoxColumn
    Friend WithEvents Label2 As Label
End Class
